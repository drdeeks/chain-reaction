## Packages
canvas-confetti | Celebration effects when winning the game
@types/canvas-confetti | Types for the confetti library

## Notes
The backend provides a pre-seeded list of puzzles via GET /api/puzzles.
No authentication is required for this version.
Game state is local for now, reset on page reload.
